import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http: HttpClient) { }

  public login(username, password) {
    // tslint:disable-next-line:max-line-length
    return this.http.post('http://127.0.0.1/bank-app-backend/login.php', { 'username': username, 'password': password }).pipe(map(res => res));
  }
  public excelData(basic, bank) {
    return this.http.post('http://127.0.0.1/bank-app-backend/ML/Codes/Excel.php',
      // tslint:disable-next-line:max-line-length
      { 'loanAmount': basic.amount, 'period': basic.period, 'EMI': basic.EMI, 'purposeofLoan': basic.PurposeOfLoan, 'securityType': basic.securityType, 'crib': basic.crib, 'profitAfterTax': bank.profitAfterTax, 'typeOfEntity': bank.typeOfEntity, 'periodOfService': bank.periodOfService, 'totalAssets': bank.TotalAssets, 'totalBurrowings': bank.totalBurrowings, 'loanInst': bank.loanInst, 'taxPaying': bank.taxPaying }).pipe(map(res => res));
  }
  public search(searchtxt) {
    return this.http.post('http://127.0.0.1/bank-app-backend/ML/Codes/search.php', { 'searchtxt': searchtxt }).pipe(map(res => res));
  }
  public register(username, email, name) {
    // tslint:disable-next-line:max-line-length
    return this.http.post('http://127.0.0.1/bank-app-backend/ML/Codes/register.php', { 'username': username, 'email': email, 'name': name }).pipe(map(res => res));
  }
}
