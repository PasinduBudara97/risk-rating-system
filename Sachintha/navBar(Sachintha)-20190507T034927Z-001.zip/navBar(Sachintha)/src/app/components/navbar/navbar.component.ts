import { Component, OnInit, ElementRef } from '@angular/core';
import { AlertService } from 'ngx-alerts';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AuthService } from 'src/app/auth.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {
  private toggleButton: any;
  private sidebarVisible: boolean;
  user = { username: '', name: '', email: '' };
  searchtxt = '';
  constructor(private element: ElementRef, private alertService: AlertService, private modalService: NgbModal, private auth: AuthService) {
    this.sidebarVisible = false;
  }
  open(content) {
    this.modalService.open(content);
  }
  ngOnInit() {
    const navbar: HTMLElement = this.element.nativeElement;
    this.toggleButton = navbar.getElementsByClassName('navbar-toggler')[0];
  }
  search() {
    this.auth.search(this.searchtxt).subscribe(success => {
      if (success === '1') {
        this.alertService.success('User have an Account');
      } else {
        this.alertService.danger('User Doesnt Exsists');
      }

    }, error => {
      this.alertService.warning('User dont have an Account');
    });
  }
  sidebarOpen() {
    const toggleButton = this.toggleButton;
    const html = document.getElementsByTagName('html')[0];
    // console.log(html);
    // console.log(toggleButton, 'toggle');

    setTimeout(function () {
      toggleButton.classList.add('toggled');
    }, 500);
    html.classList.add('nav-open');

    this.sidebarVisible = true;
  }
  sidebarClose() {
    const html = document.getElementsByTagName('html')[0];
    // console.log(html);
    this.toggleButton.classList.remove('toggled');
    this.sidebarVisible = false;
    html.classList.remove('nav-open');
  }
  sidebarToggle() {
    // const toggleButton = this.toggleButton;
    // const body = document.getElementsByTagName('body')[0];
    if (this.sidebarVisible === false) {
      this.sidebarOpen();
    } else {
      this.sidebarClose();
    }
  }
  Register() {
    if (this.user.username !== '' && this.user.name !== '' && this.user.email !== '') {
      this.auth.register(this.user.username, this.user.email, this.user.name).subscribe(success => {
        if (success === '1') {
          this.alertService.warning('User Already Exsists');
        } else {
          this.alertService.success('User Added Successfully');
          this.modalService.dismissAll();
        }

      }, error => {
        this.alertService.danger('Error Connecting to Server');
      });
    } else {
      this.alertService.danger('Please Fill All Details');
    }

  }
}
