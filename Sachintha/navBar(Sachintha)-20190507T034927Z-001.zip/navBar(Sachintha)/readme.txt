How Works.
copy contents in frontend folder
run 'npm install' to install dependencies

copy backend folder to 
xampp/htdocs
run apache and mysql

run 'ng serve' angular live server

whats going on,
in angular front end first it uses two components login and userdetails
both components are using angular routes and when login details entered it check with the details in local storage then redirect to the userdetails page and in user details page it takes several inputs and according to the inputs the eligibility calculated.
to calculate the eligiblity it sends user inputs via http module to php backend as json and those data will decoded and used to write in csv file and then exec function will run the python code and take the output file and read the details in output file and send it to the front end as a json and in front end check the type and decide eligibility