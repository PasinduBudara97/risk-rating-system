import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/auth.service';
import { AlertService } from 'ngx-alerts';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  focus;
  focus1;
  user = { username: '', password: '' };
  constructor(private router: Router, private auth: AuthService, private alertService: AlertService) { }

  ngOnInit() {
    localStorage.setItem('username', 'admin');
    localStorage.setItem('password', 'pass');
  }
  login() {
    if (this.user.username !== '' && this.user.password !== '') {
      // this.auth.login(this.user.username, this.user.password).subscribe(success => {
      //   this.router.navigate(['user-details']);
      //   localStorage.setItem('username', this.user.username);
      // }, error => {
      //   console.log(error);
      // });
      if (localStorage.getItem('username') === this.user.username && localStorage.getItem('password') === this.user.password) {
        this.router.navigate(['user-details']);
      } else {
        this.alertService.danger('Invalid Credentials');
      }
    }
  }
}
